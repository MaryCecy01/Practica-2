package CuartaSesion;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// Calcular si untriángulo es isosceles,equilatero o escaleno
		Scanner teclado= new Scanner(System.in);
		int a, b, c;
		
		do {
			System.out.println("Ingrese primer lado");
			a= teclado.nextInt();
			System.out.println("Ingrese segundo lado");
			b= teclado.nextInt();
			System.out.println("Ingrese tercer lado");
			c= teclado.nextInt();
		}
		
		while(a<=0 || b<=0 || c<=0);
		
		if (a==b && b==c) {
			System.out.println("Es un triangulo equilatero");
		}
			
			else if (a==b || a==c || b==c) {
				System.out.println("Es un triangulo isosceles");
			}
				else {
					System.out.println("Es un triangulo escaleno");
				}
			
		
	}

}
