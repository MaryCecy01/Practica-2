package CuartaSesion;
import java.util.Scanner;

public class main2 {

	public static void main(String[] args) {
		// Ver si un numero es par o impar
		Scanner teclado= new Scanner(System.in);
		
		int a;
		
		System.out.println("Ingrese un numero");
		a = teclado.nextInt();
		
		// Operacion
		if (a%2==1) {
		   System.out.println("Es impar");
		}
		else {
			System.out.println("Es par");
		}
	}

}
