package CuartaSesion;

import java.util.Scanner;

public class main3 {

	public static void main(String[] args) {
		// Ver si un año es bisiesto o no
		Scanner teclado= new Scanner(System.in);
		int año;
		
		System.out.println("Ingrese el año");
		año =teclado.nextInt();
		
		if(año%100!=0) {
			if(año%4==0)
				System.out.println("Año bisiesto");
			else 
				System.out.println("Año No bisiesto");
		}else if (año%400==0)
			System.out.println("Año bisiesto");
		else 
			System.out.println("Año No bisiesto");

	}

}
